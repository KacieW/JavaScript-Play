//controller
var controller = {
	guesses:0,
	guessPlaceArr:[],
	processGuess:function(guess){
		var location = parseGuess(guess);
		var temp=this.guessPlaceArr.indexOf(location);
		console.log("temp is "+temp);
		if(temp<0){
			this.guessPlaceArr.push(location);
			console.log("single input "+this.guessPlaceArr);
			if(location){
				this.guesses++;
				var hit = model.fire(location);
				if(hit && model.shipsSunk===model.numShips){
					view.displayMessage("You sank all my battleships, in "+this.guesses+" guesses");
					OneMore();
				}
			}
		}else{
			alert("duplicated input");
		} 	
	}
}
function OneMore(){
	document.getElementById("guessForm").removeChild(document.getElementById("guessInput"));
	document.getElementById("guessForm").removeChild(document.getElementById("fireButton"));
	var node = document.createElement("button");
	var textnode = document.createTextNode("One More Time");
	node.appendChild(textnode);
	document.getElementById("guessForm").appendChild(node);
}
function parseGuess(guess){
	if(guess.length!==2 || guess===null){
		alert("please put a letter followed by a number!");
	}
	var letterArr = ["A", "B", "C", "D", "E", "F", "G"];
	var firstLetter = guess.charAt(0).toUpperCase();
	var row = letterArr.indexOf(firstLetter);
	var secondNumber = guess.charAt(1);
	if(isNaN(secondNumber)||isNaN(row)){
		alert("second input should be a number");
	}else if(row<0 || row>=model.boardSize || secondNumber<0 ||secondNumber>=model.boardSize){
		alert("out of range");
	}else{
		return row+secondNumber;
	}
	return null;
}
//model	
var model = {
				boardSize:7, 
				numShips:3, 
				shipsSunk:0, 
				shipLength:3,
				
				ships:[{locations:[0, 0, 0], hits:["","",""]}, 
						{locations:[0, 0, 0], hits:["","",""]}, 
						{locations:[0, 0, 0], hits:["","",""]}], 
				
				generateShipLocations:function(){
					var locations;
					for(var i=0;i<this.numShips; i++){
						do{
							locations = this.generateShip();
						}
						while(this.collision(locations));
						this.ships[i].locations = locations;
					}
					
				},
				generateShip: function(){
					var direction =Math.floor(Math.random()*2);
					if(direction===1){
						var firstNum=Math.floor(Math.random()*this.boardSize);
						var secondNum = Math.floor(Math.random()*(this.boardSize-3)+1);
					}else{
						var firstNum=Math.floor(Math.random()*(this.boardSize-3)+1);
						var secondNum = Math.floor(Math.random()*this.boardSize);
					}
					var newShipLocations=[];
					for(var i=0; i<this.shipLength; i++){
						if(direction===1){
							newShipLocations.push(firstNum+""+(secondNum+i));
						}else{
							newShipLocations.push((firstNum+i)+""+secondNum);
						}
					}
					return newShipLocations;
				},
				collision:function(locations){
					for(var i=0; i<this.numShips;i++){
						var ship = model.ships[i];
						console.log(ship);
						for(var j=0; j<locations.length;j++){
							if(ship.locations.indexOf(locations[j])>=0){
								return true;
							}
						}
					}
					return false;//no collision
				},
				isSunk:function(ship){
					for(var i=0;i<this.shipLength; i++){
						if(ship.hits[i]!="hit"){
							return false;
						}
					}
					return true;
				},
				fire: function(guess){
					for(var i=0; i<this.numShips; i++){
						var ship = this.ships[i];
						var index = ship.locations.indexOf(guess);
						
						if(index>=0){
							ship.hits[index]="hit";
							view.displayHit(guess);
							view.displayMessage("HIT!");
							if(this.isSunk(ship)){
								view.displayMessage("You sank "+(this.shipsSunk+1)+" battleship!");
								this.shipsSunk++;
							}
							return true;
						}
					}
					view.displayMiss(guess);
					view.displayMessage("you missed");
					return false;
				}
			};
				
//view
var view={
	displayMessage:function(msg){
		var message = document.getElementById("messageArea");
		message.innerHTML = msg;
	},
	displayHit: function(location){
		var tablecell = document.getElementById(location);
		tablecell.setAttribute("class", "hit");
	},
	displayMiss: function(location){
		var tablecell = document.getElementById(location);
		tablecell.setAttribute("class", "miss");
	}
}

function init(){
	var fireButton = document.getElementById("fireButton");
	fireButton.onclick= handleFireButton;
	var guessInput = document.getElementById("guessInput");
	guessInput.onkeypress = handleKeyPress;
	
	model.generateShipLocations();
}
function handleKeyPress(e){
	var fireButton = document.getElementById("fireButton");
	if(e.keyCode===13){
		fireButton.click();
		return false;
	}
}
function handleFireButton(){
	var userInput = document.getElementById("guessInput");
	var guess = userInput.value;
	controller.processGuess(guess);
	userInput.value = "";
}
init();